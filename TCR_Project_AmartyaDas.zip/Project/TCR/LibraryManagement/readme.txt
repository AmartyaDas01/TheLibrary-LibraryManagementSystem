For The Library Admin Panel:
Username: amartyadas
Password: amartya123

For Django Admin Panel:
Username: adminlib
Password: tcrproject